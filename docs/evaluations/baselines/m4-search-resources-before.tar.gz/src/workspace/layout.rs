//! 仅 UI 元数据的版本化布局。一个工作线程、一个待写槽、各一个读取/保存结果槽。
//! 不持有终端、路径、标题、命令、环境变量或输入缓冲。
use super::{Axis, MAX_PANES, Node};
use crate::session::Notify;
use std::fmt::Write as _;
use std::fs::{File, OpenOptions};
use std::io::{Read, Write};
use std::path::{Path, PathBuf};
use std::sync::{Arc, Condvar, Mutex};
use std::time::{Duration, Instant};

const MAX_BYTES: usize = 4096;
const HEADER: &str = "congminal-layout";
const INVALID: &str = "布局格式无效或超出 8 个会话限制，保留初始终端";
pub(super) const SAVE_DELAY: Duration = Duration::from_millis(400);

#[derive(Clone, Debug, PartialEq, Eq)]
pub(super) struct Layout {
    pub enabled: bool,
    pub left: bool,
    pub right: bool,
    // 逻辑像素，不保存操作系统窗口坐标或 DPI。
    pub left_width: u16,
    pub right_width: u16,
    pub active: usize,
    pub tabs: Vec<(Node, u64)>,
}
impl Layout {
    pub fn count(&self) -> usize {
        self.tabs.iter().map(|(tree, _)| count(tree)).sum()
    }
    fn validate(&self) -> Result<(), String> {
        fn visit(node: &Node, depth: usize, seen: &mut [bool; MAX_PANES]) -> Result<(), String> {
            if depth > MAX_PANES {
                return Err(INVALID.into());
            }
            match node {
                Node::Leaf(id) => {
                    let i = usize::try_from(*id).ok().and_then(|id| id.checked_sub(1));
                    let slot = i.and_then(|i| seen.get_mut(i)).ok_or(INVALID)?;
                    if *slot {
                        return Err(INVALID.into());
                    }
                    *slot = true;
                }
                Node::Split { ratio, left, right, .. } => {
                    if !(150..=850).contains(ratio) {
                        return Err(INVALID.into());
                    }
                    visit(left, depth + 1, seen)?;
                    visit(right, depth + 1, seen)?;
                }
            }
            Ok(())
        }
        if self.tabs.is_empty()
            || self.tabs.len() > MAX_PANES
            || self.active >= self.tabs.len()
            || !(80..=2048).contains(&self.left_width)
            || !(80..=2048).contains(&self.right_width)
        {
            return Err(INVALID.into());
        }
        let mut seen = [false; MAX_PANES];
        for (node, focus) in &self.tabs {
            visit(node, 1, &mut seen)?;
            if !node.contains(*focus) {
                return Err(INVALID.into());
            }
        }
        let count = seen.iter().filter(|v| **v).count();
        if seen[..count].iter().any(|v| !v) || (!self.enabled && (count != 1 || self.left || self.right)) {
            return Err(INVALID.into());
        }
        Ok(())
    }
    pub fn encode(&self) -> Result<String, String> {
        fn node(out: &mut String, tree: &Node) {
            match tree {
                Node::Leaf(id) => write!(out, " p {id}").unwrap(),
                Node::Split { axis, ratio, left, right } => {
                    write!(out, " {} {ratio}", if *axis == Axis::Across { "h" } else { "v" }).unwrap();
                    node(out, left);
                    node(out, right);
                }
            }
        }
        self.validate()?;
        let mut out = format!(
            "{HEADER} 1\nview {} {} {} {} {}\nactive {}\n",
            u8::from(self.enabled),
            u8::from(self.left),
            u8::from(self.right),
            self.left_width,
            self.right_width,
            self.active
        );
        for (tree, focus) in &self.tabs {
            write!(out, "tab {focus}").unwrap();
            node(&mut out, tree);
            out.push('\n');
        }
        out.push_str("end\n");
        debug_assert!(out.len() <= MAX_BYTES);
        Ok(out)
    }
    pub fn parse(text: &str) -> Result<Self, String> {
        fn number<T: std::str::FromStr>(tokens: &mut std::str::SplitAsciiWhitespace<'_>) -> Result<T, String> {
            tokens.next().and_then(|s| s.parse().ok()).ok_or_else(|| INVALID.into())
        }
        fn flag(tokens: &mut std::str::SplitAsciiWhitespace<'_>) -> Result<bool, String> {
            match tokens.next() {
                Some("0") => Ok(false),
                Some("1") => Ok(true),
                _ => Err(INVALID.into()),
            }
        }
        fn node(
            tokens: &mut std::str::SplitAsciiWhitespace<'_>,
            depth: usize,
            nodes: &mut usize,
        ) -> Result<Node, String> {
            *nodes += 1;
            if depth > MAX_PANES || *nodes > MAX_PANES * 2 - 1 {
                return Err(INVALID.into());
            }
            match tokens.next() {
                Some("p") => Ok(Node::Leaf(number(tokens)?)),
                Some(axis @ ("h" | "v")) => {
                    let ratio = number(tokens)?;
                    let left = Box::new(node(tokens, depth + 1, nodes)?);
                    let right = Box::new(node(tokens, depth + 1, nodes)?);
                    Ok(Node::Split { axis: if axis == "h" { Axis::Across } else { Axis::Down }, ratio, left, right })
                }
                _ => Err(INVALID.into()),
            }
        }
        if text.len() > MAX_BYTES || !text.is_ascii() {
            return Err(INVALID.into());
        }
        let mut tokens = text.split_ascii_whitespace();
        if tokens.next() != Some(HEADER) || tokens.next() != Some("1") || tokens.next() != Some("view") {
            return Err("布局版本不支持或文件损坏，保留初始终端".into());
        }
        let mut layout = Self {
            enabled: flag(&mut tokens)?,
            left: flag(&mut tokens)?,
            right: flag(&mut tokens)?,
            left_width: number(&mut tokens)?,
            right_width: number(&mut tokens)?,
            active: 0,
            tabs: Vec::new(),
        };
        if tokens.next() != Some("active") {
            return Err(INVALID.into());
        }
        layout.active = number(&mut tokens)?;
        let mut nodes = 0;
        loop {
            match tokens.next() {
                Some("tab") if layout.tabs.len() < MAX_PANES => {
                    let focus = number(&mut tokens)?;
                    layout.tabs.push((node(&mut tokens, 1, &mut nodes)?, focus));
                }
                Some("end") if tokens.next().is_none() => break,
                _ => return Err(INVALID.into()),
            }
        }
        layout.validate()?;
        Ok(layout)
    }
}
fn count(node: &Node) -> usize {
    match node {
        Node::Leaf(_) => 1,
        Node::Split { left, right, .. } => count(left) + count(right),
    }
}

pub(super) fn path(config: &Path) -> Result<PathBuf, String> {
    let mut name = config.file_name().ok_or("无法确定布局文件名")?.to_os_string();
    name.push(".workspace");
    let path = config.with_file_name(name);
    // 启动时固定绝对位置，不受之后的相对路径语义影响。
    if path.is_absolute() {
        Ok(path)
    } else {
        std::env::current_dir().map(|dir| dir.join(path)).map_err(|e| e.to_string())
    }
}
fn read(path: &Path) -> Result<Option<Layout>, String> {
    let meta = match std::fs::symlink_metadata(path) {
        Ok(meta) => meta,
        Err(e) if e.kind() == std::io::ErrorKind::NotFound => return Ok(None),
        Err(e) => return Err(format!("读取布局失败：{e}")),
    };
    if !meta.is_file() || meta.len() > MAX_BYTES as u64 {
        return Err("布局必须是至多 4 KiB 的普通文件".into());
    }
    let mut file = File::open(path).map_err(|e| format!("读取布局失败：{e}"))?;
    let mut bytes = [0; MAX_BYTES + 1];
    let mut len = 0;
    while len < bytes.len() {
        match file.read(&mut bytes[len..]) {
            Ok(0) => break,
            Ok(n) => len += n,
            Err(e) if e.kind() == std::io::ErrorKind::Interrupted => continue,
            Err(e) => return Err(format!("读取布局失败：{e}")),
        }
    }
    let text = std::str::from_utf8(&bytes[..len]).map_err(|_| INVALID)?;
    Layout::parse(text).map(Some)
}

fn write(path: &Path, layout: &Layout) -> Result<(), String> {
    use std::sync::atomic::{AtomicU64, Ordering};
    static SEQUENCE: AtomicU64 = AtomicU64::new(1);
    let text = layout.encode()?;
    let parent = path.parent().ok_or("布局目录无效")?;
    std::fs::create_dir_all(parent).map_err(|e| format!("创建布局目录失败：{e}"))?;
    // 同目录独占临时文件，绝不先截断旧布局。Windows 上也须关闭句柄后替换。
    for _ in 0..16 {
        let temp = parent.join(format!(
            ".congminal-layout-{}-{}.tmp",
            std::process::id(),
            SEQUENCE.fetch_add(1, Ordering::Relaxed)
        ));
        let mut options = OpenOptions::new();
        options.write(true).create_new(true);
        #[cfg(unix)]
        {
            use std::os::unix::fs::OpenOptionsExt;
            options.mode(0o600);
        }
        let mut file = match options.open(&temp) {
            Ok(file) => file,
            Err(e) if e.kind() == std::io::ErrorKind::AlreadyExists => continue,
            Err(e) => return Err(format!("保存布局失败：{e}")),
        };
        let saved = file.write_all(text.as_bytes()).and_then(|_| file.sync_all());
        drop(file);
        let result = saved.and_then(|_| std::fs::rename(&temp, path));
        if let Err(error) = result {
            let _ = std::fs::remove_file(&temp);
            return Err(format!("保存布局失败，旧文件保留：{error}"));
        }
        return Ok(());
    }
    Err("无法创建布局临时文件，旧文件保留".into())
}

#[derive(Default)]
struct State {
    loaded: Option<Result<Option<Layout>, String>>,
    saved: Option<Result<(), String>>,
    pending: Option<(u64, Layout)>,
    submitted: u64,
    completed: u64,
    closed: bool,
}
#[derive(Default)]
struct Shared {
    state: Mutex<State>,
    changed: Condvar,
}
pub(super) struct Store(Arc<Shared>);
impl Store {
    pub fn start(path: PathBuf, notify: Notify) -> std::io::Result<Self> {
        let shared = Arc::new(Shared::default());
        let worker = shared.clone();
        std::thread::Builder::new().name("workspace-layout".into()).spawn(move || {
            let loaded = read(&path);
            worker.state.lock().unwrap().loaded = Some(loaded);
            notify();
            loop {
                let (version, layout) = {
                    let mut state = worker.state.lock().unwrap();
                    while state.pending.is_none() && !state.closed {
                        state = worker.changed.wait(state).unwrap();
                    }
                    let Some(job) = state.pending.take() else { return };
                    job
                };
                let saved = write(&path, &layout);
                let mut state = worker.state.lock().unwrap();
                state.completed = version;
                state.saved = Some(saved);
                worker.changed.notify_all();
                let closed = state.closed;
                drop(state);
                if !closed {
                    notify();
                }
            }
        })?;
        Ok(Self(shared))
    }
    pub fn loaded(&self) -> Option<Result<Option<Layout>, String>> {
        self.0.state.lock().unwrap().loaded.take()
    }
    pub fn saved(&self) -> Option<Result<(), String>> {
        self.0.state.lock().unwrap().saved.take()
    }
    pub fn submit(&self, layout: Layout) {
        let mut state = self.0.state.lock().unwrap();
        if !state.closed {
            state.submitted += 1;
            state.pending = Some((state.submitted, layout));
            self.0.changed.notify_one();
        }
    }
    /// 窗口退出后至多等 250 ms；不 join 可能卡在网络盘的内核 I/O。
    pub fn finish(&self) -> Result<(), String> {
        let mut state = self.0.state.lock().unwrap();
        state.closed = true;
        self.0.changed.notify_one();
        let until = Instant::now() + Duration::from_millis(250);
        while state.completed < state.submitted {
            let left = until.saturating_duration_since(Instant::now());
            if left.is_zero() {
                return Err("布局保存超过 250 ms，退出不再等待；最新变动可能未保存".into());
            }
            state = self.0.changed.wait_timeout(state, left).unwrap().0;
        }
        state.saved.take().unwrap_or(Ok(()))
    }
}
impl Drop for Store {
    fn drop(&mut self) {
        let mut state = self.0.state.lock().unwrap();
        state.closed = true;
        self.0.changed.notify_one();
    }
}

#[cfg(test)]
pub(super) struct TestDir(pub PathBuf);
#[cfg(test)]
impl TestDir {
    pub fn new() -> Self {
        use std::sync::atomic::{AtomicU64, Ordering};
        static ID: AtomicU64 = AtomicU64::new(0);
        let now = std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).unwrap().as_nanos();
        let path = std::env::temp_dir().join(format!(
            "congminal-layout-test-{}-{now}-{}",
            std::process::id(),
            ID.fetch_add(1, Ordering::Relaxed)
        ));
        std::fs::create_dir(&path).unwrap();
        Self(path)
    }
}
#[cfg(test)]
impl Drop for TestDir {
    fn drop(&mut self) {
        let _ = std::fs::remove_dir_all(&self.0);
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    fn sample() -> Layout {
        Layout {
            enabled: true,
            left: true,
            right: false,
            left_width: 220,
            right_width: 280,
            active: 0,
            tabs: vec![(Node::Leaf(1), 1)],
        }
    }
    #[test]
    fn complete_eight_pane_layout_roundtrips_and_paths_are_per_config() {
        let mut layout = sample();
        for id in 2..=8 {
            assert!(layout.tabs[0].0.split(id - 1, id, if id % 2 == 0 { Axis::Across } else { Axis::Down }));
        }
        layout.tabs[0].1 = 8;
        let text = layout.encode().unwrap();
        assert!(text.len() < 512);
        assert_eq!(Layout::parse(&text).unwrap(), layout);
        let dir = TestDir::new();
        let a = path(&dir.0.join("a.toml")).unwrap();
        let b = path(&dir.0.join("b.toml")).unwrap();
        assert_ne!(a, b);
        assert!(a.is_absolute());
        assert_eq!(a.file_name().unwrap(), "a.toml.workspace");
    }
    #[test]
    fn malformed_version_trees_ids_focus_and_sizes_are_rejected_before_spawn() {
        let valid = sample().encode().unwrap();
        for bad in [
            valid.replace("layout 1", "layout 2"),
            valid.replace("view 1", "view 0"),
            valid.replace("220", "99999"),
            valid.replace("220", "79"),
            valid.replace("active 0", "active 1"),
            valid.replace("tab 1", "tab 2"),
            valid.replace("p 1", "p 2"),
            valid.replace("p 1", "p 0"),
            valid.replace("p 1", "h 149 p 1 p 2"),
            valid.replace("p 1", "v 851 p 1 p 2"),
            valid.replace("p 1", "h 500 p 1 p 1"),
            valid.replace("p 1", "h 500 p 1"),
            valid.replace("p 1", "h 500 p 1 p 3"),
            valid.replace("end", "end COMMAND"),
            valid.replace("end", "tab 1 p 1 end"),
            valid.replace("end", ""),
            valid.replace("p 1", &format!("{}p 1", "h 500 ".repeat(300))),
            "x".repeat(MAX_BYTES + 1),
            valid.replace("p 1", "p 命令"),
        ] {
            assert!(Layout::parse(&bad).is_err(), "accepted {bad}");
        }
        // 有界随机字节和有效文件的所有截断，不允许 panic 或接受半棵树。
        for end in 0..valid.find("end").unwrap() + 3 {
            assert!(Layout::parse(&valid[..end]).is_err());
        }
        let mut seed = 17u32;
        for length in 0..1500 {
            let text: String = (0..length)
                .map(|_| {
                    seed = seed.wrapping_mul(1664525).wrapping_add(1013904223);
                    char::from((seed >> 24) as u8 & 127)
                })
                .collect();
            assert!(Layout::parse(&text).is_err());
        }
    }
    #[test]
    fn bounded_reader_rejects_non_regular_and_oversized_files() {
        let dir = TestDir::new();
        let file = dir.0.join("layout");
        assert_eq!(read(&file).unwrap(), None);
        assert!(read(&dir.0).is_err());
        std::fs::write(&file, [0xff]).unwrap();
        assert!(read(&file).is_err());
        std::fs::write(&file, vec![b' '; MAX_BYTES + 1]).unwrap();
        assert!(read(&file).is_err());
        #[cfg(unix)]
        {
            let link = dir.0.join("link");
            std::os::unix::fs::symlink(&file, &link).unwrap();
            assert!(read(&link).is_err());
        }
    }
    #[test]
    fn replacement_is_whole_and_failure_preserves_existing_target() {
        let dir = TestDir::new();
        let file = dir.0.join("layout");
        let mut layout = sample();
        write(&file, &layout).unwrap();
        let reader_path = file.clone();
        let reader = std::thread::spawn(move || {
            for _ in 0..400 {
                assert!(read(&reader_path).unwrap().is_some());
            }
        });
        for width in 220..260 {
            layout.left_width = width;
            write(&file, &layout).unwrap();
        }
        reader.join().unwrap();
        assert_eq!(read(&file).unwrap(), Some(layout.clone()));
        #[cfg(unix)]
        {
            use std::os::unix::fs::PermissionsExt;
            assert_eq!(std::fs::metadata(&file).unwrap().permissions().mode() & 0o777, 0o600);
        }
        let blocked = dir.0.join("directory");
        std::fs::create_dir(&blocked).unwrap();
        std::fs::write(blocked.join("keep"), "old").unwrap();
        assert!(write(&blocked, &layout).is_err());
        assert_eq!(std::fs::read_to_string(blocked.join("keep")).unwrap(), "old");
        assert!(
            std::fs::read_dir(&dir.0).unwrap().all(|entry| !entry
                .unwrap()
                .file_name()
                .to_string_lossy()
                .ends_with(".tmp"))
        );
    }
    #[test]
    fn latest_save_is_bounded_and_finish_drains_it() {
        let dir = TestDir::new();
        let path = dir.0.join("nested/layout");
        let (send, ready) = std::sync::mpsc::sync_channel(1);
        let store = Store::start(
            path.clone(),
            Arc::new(move || {
                let _ = send.try_send(());
            }),
        )
        .unwrap();
        ready.recv_timeout(Duration::from_secs(3)).unwrap();
        assert!(store.loaded().unwrap().unwrap().is_none());
        for i in 0..1000 {
            let mut layout = sample();
            layout.left_width = 100 + i;
            store.submit(layout);
        }
        let latest = {
            let state = store.0.state.lock().unwrap();
            state.submitted
        };
        let until = Instant::now() + Duration::from_secs(3);
        while store.0.state.lock().unwrap().completed < latest {
            assert!(Instant::now() < until);
            let _ = ready.recv_timeout(Duration::from_millis(10));
        }
        store.finish().unwrap();
        assert_eq!(read(&path).unwrap().unwrap().left_width, 1099);
        store.submit(sample()); // closed 后不再接收。
        assert_eq!(store.0.state.lock().unwrap().submitted, latest);
    }
    #[test]
    fn finish_has_a_deadline_even_if_io_never_completes() {
        let shared = Arc::new(Shared::default());
        shared.state.lock().unwrap().submitted = 1;
        let store = Store(shared);
        let started = Instant::now();
        assert!(store.finish().unwrap_err().contains("250 ms"));
        assert!(started.elapsed() < Duration::from_secs(2));
    }
}

//! GUI 工作器与受限 helper 共用的取消原语。
use std::{
    sync::{
        Arc, Condvar, Mutex,
        atomic::{AtomicBool, Ordering},
    },
    time::Duration,
};
#[derive(Clone, Default)]
pub struct Cancellation(Arc<CancelState>);
#[derive(Default)]
struct CancelState {
    cancelled: AtomicBool,
    gate: Mutex<()>,
    changed: Condvar,
}
impl Cancellation {
    pub fn cancel(&self) {
        let _gate = self.0.gate.lock().unwrap();
        self.0.cancelled.store(true, Ordering::Release);
        self.0.changed.notify_all();
    }
    pub fn is_cancelled(&self) -> bool {
        self.0.cancelled.load(Ordering::Acquire)
    }
    /// 取消立即唤醒；没有任务时不轮询。
    pub fn wait(&self, duration: Duration) -> bool {
        let gate = self.0.gate.lock().unwrap();
        let _guard = self.0.changed.wait_timeout_while(gate, duration, |_| !self.is_cancelled()).unwrap();
        self.is_cancelled()
    }
}

//! 普通粘贴保持既有行为；受保护结果保留原视图和额度，所有丢弃路径清理应用副本。
use super::{ClipboardRead, Event};
use crate::resources::{Budget, Denied, Kind, Lease};
use std::sync::Arc;

/// 由输入所有者提供的完整起始身份；平台只携带，不用当前焦点重写。
#[derive(Clone, Copy, PartialEq, Eq)]
pub(crate) struct InputOrigin([u64; 5]);
impl InputOrigin {
    #[cfg_attr(not(test), allow(dead_code))]
    pub(crate) fn new(identity: [u64; 5]) -> Self {
        Self(identity)
    }
}

pub(super) struct ClearText(pub(super) String);
impl Drop for ClearText {
    fn drop(&mut self) {
        for byte in unsafe { self.0.as_bytes_mut() } {
            unsafe { std::ptr::write_volatile(byte, 0) };
        }
    }
}
struct ProtectedData {
    origin: InputOrigin,
    policy: ClipboardRead,
    text: Option<ClearText>,
}
/// 不支持 Clone/Debug/Display。data（包括 Box）先于额度释放。
pub(crate) struct ProtectedPaste {
    data: Box<ProtectedData>,
    _memory: Lease,
}
impl ProtectedPaste {
    #[cfg_attr(not(test), allow(dead_code))]
    pub(crate) fn uses(&self, pool: &Arc<Budget>) -> bool {
        self._memory.belongs_to(pool)
    }
    #[cfg_attr(not(test), allow(dead_code))]
    pub(crate) fn origin(&self) -> InputOrigin {
        self.data.origin
    }
    #[cfg_attr(not(test), allow(dead_code))]
    pub(crate) fn text(&self) -> Option<&str> {
        self.data.text.as_ref().map(|text| text.0.as_str())
    }
}

pub(crate) enum PasteRequest {
    Plain(ClipboardRead),
    #[cfg_attr(not(test), allow(dead_code))]
    Protected(ProtectedPaste),
}
impl Default for PasteRequest {
    fn default() -> Self {
        Self::Plain(ClipboardRead::default())
    }
}
impl PasteRequest {
    /// 在读取平台数据前准入，额度随在途请求/结果移动，不依赖 Editor 存活。
    #[cfg_attr(not(test), allow(dead_code))]
    pub(crate) fn protected(origin: InputOrigin, limit: usize, pool: &Arc<Budget>) -> Result<Self, Denied> {
        let policy = ClipboardRead { limit: limit.min(super::CLIPBOARD_LIMIT), strict_unicode: true };
        let memory = pool.lease(
            Kind::Sftp,
            policy.limit() + std::mem::size_of::<ProtectedData>() + std::mem::size_of::<ProtectedPaste>() + 128,
        )?;
        let data = Box::new(ProtectedData { origin, policy, text: None });
        Ok(Self::Protected(ProtectedPaste { data, _memory: memory }))
    }
    pub(crate) fn policy(&self) -> ClipboardRead {
        match self {
            Self::Plain(policy) => *policy,
            Self::Protected(paste) => paste.data.policy,
        }
    }
    pub(crate) fn finish(self, text: Option<String>) -> Event {
        match self {
            Self::Plain(_) => text.map_or(Event::PasteFailed, Event::Paste),
            Self::Protected(mut paste) => {
                // 平台必须先限量；这里防止错误适配器把超容量副本带到下一层。
                // 拒绝也以 ClearText 拥有，释放前清理，不截成另一个答案。
                paste.data.text = text.map(ClearText).filter(|text| text.0.capacity() <= paste.data.policy.limit());
                Event::ProtectedPaste(paste)
            }
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn protected_paste_preserves_origin_and_credit_until_result_is_discarded() {
        let pool = Budget::new(4096, 0);
        let origin = InputOrigin::new([1, 2, 3, 4, 5]);
        let request = PasteRequest::protected(origin, 1023, &pool).unwrap();
        let used = pool.snapshot().used;
        assert!(used > 1023);
        assert!(request.policy().strict_unicode);
        assert_eq!(request.policy().limit(), 1023);
        let source = "x".repeat(1020) + "文";
        let text = request.policy().utf8(source.as_bytes());
        let Event::ProtectedPaste(result) = request.finish(text) else { panic!() };
        assert!(result.uses(&pool));
        assert!(!result.uses(&Budget::new(4096, 0)));
        assert!(result.origin() == origin);
        assert_eq!(result.text().unwrap().len(), 1023);
        assert_eq!(pool.snapshot().used, used);
        drop(result);
        assert_eq!(pool.snapshot().used, 0);
    }
    #[test]
    fn protected_failures_do_not_become_plain_paste_and_plain_requests_keep_their_result() {
        let pool = Budget::new(4096, 0);
        let origin = InputOrigin::new([1, 2, 3, 4, 5]);
        for text in [None, Some("x".repeat(1024)), Some(String::with_capacity(4096))] {
            let request = PasteRequest::protected(origin, 1023, &pool).unwrap();
            let Event::ProtectedPaste(result) = request.finish(text) else { panic!() };
            assert!(result.origin() == origin);
            assert!(result.text().is_none());
            drop(result);
            assert_eq!(pool.snapshot().used, 0);
        }
        assert!(matches!(PasteRequest::default().finish(None), Event::PasteFailed));
        assert!(matches!(PasteRequest::default().finish(Some("plain".into())), Event::Paste(s) if s=="plain"));
        let no_space = Budget::new(1023, 0);
        assert!(PasteRequest::protected(origin, 1023, &no_space).is_err());
        assert_eq!(no_space.snapshot().used, 0);
        drop(PasteRequest::protected(origin, 1023, &pool).unwrap());
        assert_eq!(pool.snapshot().used, 0);
    }
}

//! Bounded process enumeration, before calling the foreign sampler. The limit is
//! visible to the UI; no unbounded System::refresh_processes(All) is permitted.
#[cfg(any(target_os = "linux", target_os = "macos", windows))]
pub(super) fn list() -> (Vec<sysinfo::Pid>, bool) {
    let mut ids = [0u32; super::PROCESS_SCAN_LIMIT];
    let (count, limited) = platform(&mut ids);
    let mut out = Vec::with_capacity(ids.len());
    out.extend(ids[..count].iter().copied().filter(|&pid| pid != 0).map(sysinfo::Pid::from_u32));
    (out, limited)
}

#[cfg(target_os = "linux")]
fn platform(ids: &mut [u32]) -> (usize, bool) {
    let Ok(directory) = std::fs::read_dir("/proc") else { return (0, true) };
    let mut count = 0;
    for (scanned, entry) in directory.enumerate() {
        if scanned >= 8192 || count == ids.len() {
            return (count, true);
        }
        let Ok(entry) = entry else { continue };
        if let Some(pid) = entry.file_name().to_str().and_then(|name| name.parse::<u32>().ok()) {
            ids[count] = pid;
            count += 1;
        }
    }
    (count, false)
}

#[cfg(target_os = "macos")]
fn platform(ids: &mut [u32]) -> (usize, bool) {
    unsafe extern "C" {
        fn proc_listpids(kind: u32, info: u32, buffer: *mut std::ffi::c_void, size: i32) -> i32;
    }
    let bytes = std::mem::size_of_val(ids);
    let read = unsafe { proc_listpids(1, 0, ids.as_mut_ptr().cast(), bytes as i32) };
    if read <= 0 {
        return (0, true);
    }
    ((read as usize / 4).min(ids.len()), read as usize >= bytes)
}

#[cfg(windows)]
fn platform(ids: &mut [u32]) -> (usize, bool) {
    #[link(name = "kernel32")]
    unsafe extern "system" {
        fn K32EnumProcesses(ids: *mut u32, size: u32, used: *mut u32) -> i32;
    }
    let bytes = std::mem::size_of_val(ids) as u32;
    let mut read = 0;
    if unsafe { K32EnumProcesses(ids.as_mut_ptr(), bytes, &mut read) } == 0 {
        return (0, true);
    }
    ((read as usize / 4).min(ids.len()), read >= bytes)
}

#[cfg(all(test, any(target_os = "linux", target_os = "macos", windows)))]
mod tests {
    #[test]
    fn native_enumeration_never_exceeds_the_input_bound() {
        let (ids, _) = super::list();
        assert!(ids.len() <= crate::monitor::PROCESS_SCAN_LIMIT);
        assert!(ids.capacity() <= crate::monitor::PROCESS_SCAN_LIMIT);
        assert!(ids.iter().all(|pid| pid.as_u32() != 0));
    }
}
